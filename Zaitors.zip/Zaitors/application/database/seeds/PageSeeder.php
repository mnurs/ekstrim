<?php

namespace Database\Seeders;

use App\Models\Admin\Page;
use Illuminate\Database\Seeder;

class PageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Page::create([
            'label' => 'home',
            'url' => '',
            'title' => 'Hospital',
            'tags' => '',
            'description' => '',
        ]);
        Page::create([
            'label' => 'about us',
            'url' => 'about-us',
            'title' => 'Hospital',
            'tags' => '',
            'description' => '',
        ]);
        Page::create([
            'label' => 'service',
            'url' => 'service',
            'title' => 'Hospital',
            'tags' => '',
            'description' => '',
        ]);
        Page::create([
            'label' => 'news',
            'url' => 'news',
            'title' => 'Hospital',
            'tags' => '',
            'description' => '',
        ]);
        Page::create([
            'label' => 'gallery',
            'url' => 'gallery',
            'title' => 'Hospital',
            'tags' => '',
            'description' => '',
        ]);
        Page::create([
            'label' => 'contact',
            'url' => 'contact',
            'title' => 'Hospital',
            'tags' => '',
            'description' => '',
        ]);
        Page::create([
            'label' => 'faq',
            'url' => 'faq',
            'title' => 'Hospital',
            'tags' => '',
            'description' => '',
        ]);

    }
}
