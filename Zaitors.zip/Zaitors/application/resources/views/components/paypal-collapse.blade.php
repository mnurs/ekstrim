<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <p class="text-danger">{{ __('Please wait, you are redirecting to paypal payment gateway') }}</p>
        </div>
    </div>
</div>