<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <input type="text" class="form-control stripefunc" name="cardname" id="cardname" placeholder="{{ __('Entar Card Name') }}" autocomplete="off" />
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <input type="text" class="form-control stripefunc" id="cardnumber" name="cardnumber" placeholder="{{ __('Enter Card Numbar') }}" autocomplete="off" />
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <input type="text" class="form-control stripefunc" id="Expariydate" name="expirymonth" placeholder="{{ __('Expariy Month') }}" autocomplete="off" />
            <span class="form-icon"><i class="far fa-calendar-alt"></i></span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <input type="text" class="form-control stripefunc" id="Expariyyear" name="expiryyear" placeholder="{{ __('Expariy Year') }}" autocomplete="off" />
            <span class="form-icon"><i class="far fa-calendar-alt"></i></span>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <input type="text" class="form-control stripefunc" name="cvv" id="ccv" placeholder="{{ __('Entar CVV') }}" autocomplete="off" />
        </div>
    </div>
</div>
