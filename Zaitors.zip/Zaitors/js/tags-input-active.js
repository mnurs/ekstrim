(function ($) {
    "use strict";

    //tags input initialization
    $(document).ready(function () {
        $('#tags').tagsinput('items');
    });
})(jQuery);