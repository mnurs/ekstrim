(function ($) {
    "use strict";

    //Select2 initialization
    $(document).ready(function () {
        $(".select2").select2();
    });
})(jQuery);
