(function ($) {
    "use strict";

    //Summernote initialization
    $(document).ready(function () {
        $('#summernote').summernote();
    });
})(jQuery);